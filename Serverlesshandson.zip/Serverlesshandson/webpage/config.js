﻿// TODO: 作成したユーザープールおよびIDプールのIDに書き換えてください
const CognitoConfig = {
    region: 'ap-northeast-1',

    // User Pool
    userPoolId: 'ap-northeast-1_OmZFTtuL1',
    appClientId: '3k02qsdaehmmrt3v4rh97qmn0k',

    // Federated Identity
    identityPoolId: 'ap-northeast-1:39a892c1-6182-4d65-81f8-a1ddcf93ee60',
}
